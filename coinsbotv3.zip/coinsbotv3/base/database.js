const Database = require("../base/Database/index");

module.exports = async () => {
    await Database();
}
