// module.js
var roulette = {};
exports.roulette = roulette;

var rate = {};
exports.rate = rate;

var wagon = {};
exports.wagon = wagon;

var allattacks = [];
exports.allattacks = allattacks

